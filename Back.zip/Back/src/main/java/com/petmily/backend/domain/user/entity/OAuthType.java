package com.petmily.backend.domain.user.entity;

public enum OAuthType {
    GOOGLE,
    NAVER,
    KAKAO
}
