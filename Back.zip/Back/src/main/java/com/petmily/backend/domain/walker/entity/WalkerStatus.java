package com.petmily.backend.domain.walker.entity;

public enum WalkerStatus {
    PENDING,
    APPROVED,
    REJECTED,
    ACTIVE,
    INACTIVE,
    UNAVAILABLE,
    SUSPENDED
}
